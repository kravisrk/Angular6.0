import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sb-ex1',
  templateUrl: './sb-ex1.component.html',
  styleUrls: ['./sb-ex1.component.css']
})
export class SbEx1Component implements OnInit {
msg='';
gender='';
name='';
  constructor() { }
style1={};
successStyle(){this.style1={'color':'green'}}
failureStyle(){this.style1={'color':'red'}}
  ngOnInit() {
  }
display(){
      if(this.gender=='m')
      {
        console.log(this.gender);
         this.successStyle();
      }
      else
      {
        console.log(this.gender);
         this.failureStyle();
      }

    this.msg='Hello'+this.gender+this.name;
  }
}
