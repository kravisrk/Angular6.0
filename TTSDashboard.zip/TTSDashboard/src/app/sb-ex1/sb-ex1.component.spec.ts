import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SbEx1Component } from './sb-ex1.component';

describe('SbEx1Component', () => {
  let component: SbEx1Component;
  let fixture: ComponentFixture<SbEx1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SbEx1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SbEx1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
