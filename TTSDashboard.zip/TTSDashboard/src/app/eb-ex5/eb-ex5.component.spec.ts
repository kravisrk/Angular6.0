import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EbEx5Component } from './eb-ex5.component';

describe('EbEx5Component', () => {
  let component: EbEx5Component;
  let fixture: ComponentFixture<EbEx5Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EbEx5Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EbEx5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
