import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb-ex5',
  templateUrl: './eb-ex5.component.html',
  styleUrls: ['./eb-ex5.component.css']
})
export class EbEx5Component implements OnInit {

  constructor() { }
name:string;
terms:boolean;
msg='';
display(){
if(this.terms)
  this.msg=`Thank You ${this.name} for accepting the terms`;
else
  this.msg=`${name}  Please go through the terms`;
}
  ngOnInit() {
  }

}
