import { PrefixPipe } from './prefix.pipe';

describe('PrefixPipe', () => {
  it('create an instance', () => {
    const pipe = new PrefixPipe();
    expect(pipe).toBeTruthy();
  });
});
