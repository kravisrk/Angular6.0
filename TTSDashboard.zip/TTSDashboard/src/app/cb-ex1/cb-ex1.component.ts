import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cb-ex1',
  templateUrl: './cb-ex1.component.html',
  styleUrls: ['./cb-ex1.component.css']
})
export class CbEx1Component implements OnInit {

  constructor() { }
headingcss='headingStyle';
  ngOnInit() {
  }

}
