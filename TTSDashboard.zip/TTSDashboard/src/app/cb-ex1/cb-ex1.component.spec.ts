import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CbEx1Component } from './cb-ex1.component';

describe('CbEx1Component', () => {
  let component: CbEx1Component;
  let fixture: ComponentFixture<CbEx1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CbEx1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CbEx1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
