import { Injectable } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
url:string='http://localhost:3000/students';
  constructor(private _http:HttpClient) { }
}
