import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KiranBackeryComponent } from './kiran-backery.component';

describe('KiranBackeryComponent', () => {
  let component: KiranBackeryComponent;
  let fixture: ComponentFixture<KiranBackeryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KiranBackeryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KiranBackeryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
