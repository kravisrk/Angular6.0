import { Component, OnInit } from '@angular/core';
import {BiscuitFactoryService} from '../biscuit-factory.service';
@Component({
  selector: 'app-kiran-backery',
  templateUrl: './kiran-backery.component.html',
  styleUrls: ['./kiran-backery.component.css'],
  providers:[BiscuitFactoryService] //register service
})
export class KiranBackeryComponent implements OnInit {
biscuits:string[];
  constructor(private _bf:BiscuitFactoryService) { }
  getBiscuitsFromService(){
    this.biscuits=this._bf.biscuits;//consume
  }
  
  ngOnInit() {
  }

}
