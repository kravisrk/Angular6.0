import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
employees=[];
x={};
msg:string;
  constructor() { 
this.employees=[
  {id:1001, ename:'Ravi1', job:'SSE', salary:'10000001'},
  {id:1002, ename:'Ravi2', job:'SSE1', salary:'10000002'},
  {id:1003, ename:'Ravi3', job:'SSE2', salary:'10000003'},
  {id:1004, ename:'Ravi4', job:'SSE3', salary:'10000004'}
];
this.msg=`Count of employees ${this.employees.length}`;
  }
search(i)
{
  //this.x=this.employees[i];
  //Cloning
  this.x=JSON.parse(JSON.stringify(this.employees[i]));

}
add()
{
  this.employees.push(this.x);
}

deleteRow(i){
  if(confirm("Are you Sure?"))
    this.employees.splice(i,1);
}

update(i)
{
  this.employees.splice(i,1);
  this.employees.push(this.x);i
}
  ngOnInit() {
  }

}
