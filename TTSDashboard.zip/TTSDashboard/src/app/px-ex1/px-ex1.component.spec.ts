import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PxEx1Component } from './px-ex1.component';

describe('PxEx1Component', () => {
  let component: PxEx1Component;
  let fixture: ComponentFixture<PxEx1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PxEx1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PxEx1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
