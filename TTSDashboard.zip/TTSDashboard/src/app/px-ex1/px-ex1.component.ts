import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-px-ex1',
  templateUrl: './px-ex1.component.html',
  styleUrls: ['./px-ex1.component.css']
})
export class PxEx1Component implements OnInit {

  constructor() { }
path1:string='./assets/20190130_124125.jpg';
  ngOnInit() {
  }

}
