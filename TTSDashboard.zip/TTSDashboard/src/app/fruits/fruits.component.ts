import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fruits',
  templateUrl: './fruits.component.html',
  styleUrls: ['./fruits.component.css']
})
export class FruitsComponent implements OnInit {
  constructor() 
  {
    this.fruits=['Apple','Banana','Cherry','Grapes','Mango','Chintakai']
   }
   fruits=[];
  ngOnInit() {
  }

}
