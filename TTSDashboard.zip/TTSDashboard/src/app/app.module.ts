import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { EbEx1Component } from './eb-ex1/eb-ex1.component';
import { EbEx2Component } from './eb-ex2/eb-ex2.component';
import { EbEx3Component } from './eb-ex3/eb-ex3.component';
import { EbEx4Component } from './eb-ex4/eb-ex4.component';
import { EbEx5Component } from './eb-ex5/eb-ex5.component';
import { PxEx1Component } from './px-ex1/px-ex1.component';
import { PxEx2Component } from './px-ex2/px-ex2.component';
import { CbEx1Component } from './cb-ex1/cb-ex1.component';
import { SbEx1Component } from './sb-ex1/sb-ex1.component';
import { EbExamplesComponent } from './eb-examples/eb-examples.component';
import { FruitsComponent } from './fruits/fruits.component';
import { ItemsComponent } from './items/items.component';
import { EmployeeComponent } from './employee/employee.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { KiranBackeryComponent } from './kiran-backery/kiran-backery.component';
import { AshokBackeryComponent } from './ashok-backery/ashok-backery.component';
import { ProductComponent } from './product/product.component';
import { PrefixPipe } from './prefix.pipe';
import { PersonComponent } from './person/person.component';
import { JokeComponent } from './joke/joke.component';
import { StudentComponent } from './student/student.component';
import { LoginComponent } from './login/login.component';
import { HelpComponent } from './help/help.component';
import { AboutComponent } from './about/about.component';
import {RouterModule} from '@angular/router';
@NgModule({
  declarations: [
    AppComponent,
    EbEx1Component,
    EbEx2Component,
    EbEx3Component,
    EbEx4Component,
    EbEx5Component,
    PxEx1Component,
    PxEx2Component,
    CbEx1Component,
    SbEx1Component,
    EbExamplesComponent,
    FruitsComponent,
    ItemsComponent,
    EmployeeComponent,
    ParentComponent,
    ChildComponent,
    KiranBackeryComponent,
    AshokBackeryComponent,
    ProductComponent,
    PrefixPipe,
    PersonComponent,
    JokeComponent,
    StudentComponent,
    LoginComponent,
    HelpComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule, FormsModule,HttpClientModule, RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  msg='';
  a:number=0;
 }
