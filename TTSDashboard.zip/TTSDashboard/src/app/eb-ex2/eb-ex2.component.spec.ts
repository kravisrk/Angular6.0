import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EbEx2Component } from './eb-ex2.component';

describe('EbEx2Component', () => {
  let component: EbEx2Component;
  let fixture: ComponentFixture<EbEx2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EbEx2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EbEx2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
