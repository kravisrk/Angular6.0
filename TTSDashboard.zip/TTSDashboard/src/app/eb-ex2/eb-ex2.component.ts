import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb-ex2',
  templateUrl: './eb-ex2.component.html',
  styleUrls: ['./eb-ex2.component.css']
})
export class EbEx2Component implements OnInit {

  constructor() { }
name:string='';
msg:string;
display(){
  this.msg='Hello '+this.name;
}
  ngOnInit() {
  }

}
