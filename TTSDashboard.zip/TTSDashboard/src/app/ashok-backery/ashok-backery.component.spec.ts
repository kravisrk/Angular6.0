import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AshokBackeryComponent } from './ashok-backery.component';

describe('AshokBackeryComponent', () => {
  let component: AshokBackeryComponent;
  let fixture: ComponentFixture<AshokBackeryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AshokBackeryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AshokBackeryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
