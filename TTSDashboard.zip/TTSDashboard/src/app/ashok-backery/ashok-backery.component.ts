import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ashok-backery',
  templateUrl: './ashok-backery.component.html',
  styleUrls: ['./ashok-backery.component.css']
})
export class AshokBackeryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
