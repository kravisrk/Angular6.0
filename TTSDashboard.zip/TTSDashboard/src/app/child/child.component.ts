import { Component, OnInit, Input } from '@angular/core';
import {Output, EventEmitter} from '@angular/core'

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input()
  parentData:string='';
  msg='';
  
  @Output()
  childEvent=new EventEmitter<string>();
  t1:string='dummy';
  sendDataToParent(){
    this.childEvent.emit(this.t1);
  }
  
  constructor() { }
  display(){
    this.msg=this.parentData;
  }


  ngOnInit() {
  }

}
