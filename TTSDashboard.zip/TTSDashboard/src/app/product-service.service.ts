import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
products:any[];
  constructor() {
    this.products=[{id:1, pname:'TV1', brand:'RK1', price:100000},
    {id:1, pname:'TV2', brand:'RK2', price:100000},
    {id:1, pname:'TV3', brand:'RK3', price:100000}];
   }
}
