import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb-ex3',
  templateUrl: './eb-ex3.component.html',
  styleUrls: ['./eb-ex3.component.css']
})
export class EbEx3Component implements OnInit {

  constructor() { }
  no1:number;
  no2:number;
  msg:string;

  Calculate(op){
    if(op=="add")
    {
      this.msg=`Add of ${this.no1} and ${this.no2}`  }
  }
  ngOnInit() {
  }

}
