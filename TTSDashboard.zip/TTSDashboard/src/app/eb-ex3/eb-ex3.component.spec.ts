import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EbEx3Component } from './eb-ex3.component';

describe('EbEx3Component', () => {
  let component: EbEx3Component;
  let fixture: ComponentFixture<EbEx3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EbEx3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EbEx3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
