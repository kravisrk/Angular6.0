import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PxEx2Component } from './px-ex2.component';

describe('PxEx2Component', () => {
  let component: PxEx2Component;
  let fixture: ComponentFixture<PxEx2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PxEx2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PxEx2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
