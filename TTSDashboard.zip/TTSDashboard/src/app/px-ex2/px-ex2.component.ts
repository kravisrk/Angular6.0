import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-px-ex2',
  templateUrl: './px-ex2.component.html',
  styleUrls: ['./px-ex2.component.css']
})
export class PxEx2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
