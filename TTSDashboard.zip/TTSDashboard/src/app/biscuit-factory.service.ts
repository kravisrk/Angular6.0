import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BiscuitFactoryService {
biscuits:string[];
  constructor() { 
    this.biscuits=['Coco','Choclate','Butter','Salt','Cheese'];
  }
}
