import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb-ex4',
  templateUrl: './eb-ex4.component.html',
  styleUrls: ['./eb-ex4.component.css']
})
export class EbEx4Component implements OnInit {

  constructor() { }
name='';
gender='';
msg='';
display(){

  this.msg='Hello'+this.gender+this.name;
}
  ngOnInit() {
  }

}
