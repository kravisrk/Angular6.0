import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EbEx4Component } from './eb-ex4.component';

describe('EbEx4Component', () => {
  let component: EbEx4Component;
  let fixture: ComponentFixture<EbEx4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EbEx4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EbEx4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
