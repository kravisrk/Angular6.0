import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb-examples',
  templateUrl: './eb-examples.component.html',
  styleUrls: ['./eb-examples.component.css']
})
export class EbExamplesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
