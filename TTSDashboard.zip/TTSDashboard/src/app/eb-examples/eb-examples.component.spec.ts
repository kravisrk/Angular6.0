import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EbExamplesComponent } from './eb-examples.component';

describe('EbExamplesComponent', () => {
  let component: EbExamplesComponent;
  let fixture: ComponentFixture<EbExamplesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EbExamplesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EbExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
