import { TestBed, inject } from '@angular/core/testing';

import { BiscuitFactoryService } from './biscuit-factory.service';

describe('BiscuitFactoryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BiscuitFactoryService]
    });
  });

  it('should be created', inject([BiscuitFactoryService], (service: BiscuitFactoryService) => {
    expect(service).toBeTruthy();
  }));
});
