import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {

  constructor() { }
  people=[{id:1, pname:'RK1', gender:"m"},
  {id:1, pname:'RK2', gender:"f"}]
  ngOnInit() {
  }

}
