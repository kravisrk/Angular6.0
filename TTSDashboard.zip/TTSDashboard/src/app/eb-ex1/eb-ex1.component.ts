import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb-ex1',
  templateUrl: './eb-ex1.component.html',
  styleUrls: ['./eb-ex1.component.css']
})
export class EbEx1Component implements OnInit {

  constructor() { }
  msg='';
sayHello(){
  this.msg="Hello";
}

  ngOnInit() {
  }

}
