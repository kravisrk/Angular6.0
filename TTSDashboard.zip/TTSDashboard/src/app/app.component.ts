import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TTS Dashboard!!!';
url:string='http://localhost:3000/students';
constructor (private _http:HttpClient){}
students:Student[];
getStudentsAPI(){

  return this._http.get<Student[]>(this.url);
}

GetStudents(){
  this.getStudentsAPI().subscribe(response => this.students=response);
}

  get(p){
    let d=new Date();
    if(p=='date')
      return d.getDate()+"/"+(d.getMonth()+1)+d.getFullYear();
    else if(p=='time')
      return d.getHours()+":"+d.getMinutes();
  }
  display(emp){
    this.msg=emp.value;
  }
msg='';
sayHello(){
  this.msg="Hello";
}
}

class Student{
  id:number
  sname:string
  course:string
}
