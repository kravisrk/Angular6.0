import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TTS Dashboard!!!';

  get(p){
    let d=new Date();
    if(p=='date')
      return d.getDate()+"/"+(d.getMonth()+1)+d.getFullYear();
    else if(p=='time')
      return d.getHours()+":"+d.getMinutes();
  }

msg='';
sayHello(){
  this.msg="Hello";
}
}
