import { Component, OnInit } from '@angular/core';
import { JokeService } from '../joke.service';

@Component({
  selector: 'app-joke',
  templateUrl: './joke.component.html',
  styleUrls: ['./joke.component.css'],
  providers:[JokeService]
})
export class JokeComponent implements OnInit {
data:any={};
  constructor(private _joke:JokeService) { }
  getJoke(){
    this.data = this._joke.getJokeFromAPI();
  }
  ngOnInit() {
  }

}
