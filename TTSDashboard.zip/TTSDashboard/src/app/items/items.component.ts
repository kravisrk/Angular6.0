import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  constructor() { }
items:string[];
fruits:string[];
vegitables:string[];
heading:string;
msg='';
  ngOnInit() {
  }
display(p)
{
  if(p=='fruits')
  {
    this.heading='List of Fruits';
    this.items=this.fruits;
  }
  else
  {
    this.heading='List of Vegitables';
    this.items=this.vegitables;
  }
  this.msg=`Count of ${p} are ${this.items.length}`;
}
}
